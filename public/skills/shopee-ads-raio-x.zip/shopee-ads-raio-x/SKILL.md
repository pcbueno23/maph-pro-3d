---
name: "shopee-ads-raio-x"
description: "Use quando o usuário pedir análise das campanhas do Shopee Ads produto a produto, para decidir onde cortar, manter ou aumentar orçamento."
---

# Raio-X das campanhas do Shopee Ads

O usuário cria uma campanha por produto e considera o ROAS do painel do Shopee Ads enganoso. Esta skill analisa cada campanha, cruza com as vendas reais do produto e recomenda o que fazer com o orçamento.

Responda sempre em português do Brasil. Trabalhe no Chrome do usuário (ferramentas do painel Claude in Chrome). Não altere nenhuma campanha sem pedido explícito.

## Passo 1. Período

Pergunte o período ou use os últimos 30 dias. Use o mesmo período em todas as fontes.

## Passo 2. Coletar as campanhas

Em Central de Marketing > Shopee Ads, com o período definido, leia de cada campanha: nome, produto, status, orçamento diário, ROAS-alvo (ou lance), impressões, cliques, CTR, conversões, vendas atribuídas, gasto, ROAS do painel e ACOS. Leia pelo DOM (`document.body.innerText`) e pagine até o fim. Se houver exportação, pode usá-la (baixar arquivo exige confirmação).

## Passo 3. Coletar as vendas reais por produto

Em Dados > Informações Gerenciais > Produtos, no mesmo período, leia de cada produto: vendas totais (R$), pedidos, visitantes e conversão. Isso inclui vendas orgânicas e de afiliados, que o painel de Ads não separa.

## Passo 4. Calcular por produto

- **ROAS real do produto** = vendas totais do produto ÷ gasto da campanha dele
- **Participação do Ads** = vendas atribuídas ÷ vendas totais do produto
- **Custo por pedido** = gasto ÷ pedidos atribuídos
- **Margem após Ads**: se o usuário passar margem por pedido (ou houver a planilha de preços), lucro do produto − gasto. Sem margem, não estime.

Para o ROAS da loja inteira dia a dia, use a skill `shopee-roas-real`.

## Passo 5. Classificar

Pergunte o ROAS mínimo que o usuário aceita (ou o ponto de equilíbrio, se ele tiver a margem). Então:
- **Escalar:** ROAS real bem acima do mínimo, gastando o orçamento inteiro todo dia (está limitado pelo orçamento).
- **Manter:** perto do mínimo e estável.
- **Ajustar:** muitos cliques e pouca conversão (problema de anúncio, preço ou fotos) ou poucas impressões (lance ou ROAS-alvo alto demais).
- **Pausar:** ROAS real abaixo do mínimo com volume suficiente para ter certeza. Não julgue campanha com menos de cerca de 20 cliques; marque como "poucos dados".

## Passo 6. Entregar

Relatório em PDF (skill `pdf`) ou tabela na resposta, como o usuário preferir: campanha, gasto, vendas atribuídas, vendas totais do produto, ROAS do painel, ROAS real, classificação e a ação sugerida com o número (ex.: subir orçamento de R$15 para R$25/dia). Termine com o total de verba que sairia das campanhas a pausar e para onde faz sentido mover.

Se o usuário pedir para aplicar as mudanças, mostre a lista exata (campanha, de, para) e só altere depois de um sim.