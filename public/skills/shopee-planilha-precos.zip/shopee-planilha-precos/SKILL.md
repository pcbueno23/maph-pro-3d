---
name: "shopee-planilha-precos"
description: "Use quando o usuário pedir a planilha Shopee de preço, cupom e margem dos anúncios, no layout fixo que o SaaS precificadora (app.maphpro3d.com) importa."
---

# Planilha Shopee de preços, cupons e margem

Gera a planilha de preços da loja Shopee no formato fixo que o SaaS de precificação (app.maphpro3d.com) importa. O SaaS lê colunas em posições fixas, então **o layout nunca pode mudar**: mesmas abas, mesmos cabeçalhos, mesma ordem de colunas, mesmo formato de números.

Responda sempre em português do Brasil.

## Passo 0. Garantir o layout

- Se o usuário anexou uma planilha modelo (ou uma versão anterior), leia com a skill `xlsx` e registre: nomes das abas, linha do cabeçalho, texto exato de cada cabeçalho, ordem, tipo de cada coluna (texto, número, moeda, %), casas decimais e se há fórmulas.
- Se não houver modelo, peça um antes de começar. Não invente colunas: um cabeçalho diferente quebra a importação.

## Passo 1. Coletar os anúncios

No Chrome do usuário (ferramentas do painel Claude in Chrome), na Central do Vendedor:

1. Em Produtos > Meus Produtos, leia todos os anúncios ativos com suas variações: nome, ID, SKU da variação, nome da variação, preço de cadastro e estoque. Leia o DOM com `javascript_tool` (`document.body.innerText`) e pagine até o fim. Confira o total com o contador da página.
2. Em Central de Marketing > Oferta Relâmpago da Loja / Desconto, leia o preço promocional e o % de desconto ativos de cada variação.
3. Em Cupons, leia os cupons da loja ativos (% ou valor, teto e pedido mínimo).
4. Se a planilha tiver colunas de custo (custo 3D, embalagem, envio), peça esses valores ao usuário ou leia de uma planilha anterior. Nunca invente custo.

Guarde os dados coletados em `localStorage` enquanto navega, porque mudar de página apaga as variáveis `window.*`. Apague as chaves no final.

Se a Central do Vendedor tiver exportação em massa de produtos, ela pode substituir a leitura do DOM. Baixar arquivo exige confirmação do usuário antes.

## Passo 2. Calcular

Use as fórmulas e taxas da skill `shopee-precificacao` (comissão, taxa fixa, transação, tributação e cupom com teto). Confirme com o usuário se as taxas mudaram. Calcule apenas as colunas que o modelo tem: preço após oferta, cupom, preço final ao cliente e margem em R$ e %.

Se o modelo usa fórmulas do Excel, escreva fórmulas, não valores fixos.

## Passo 3. Montar e validar

1. Gere o .xlsx com a skill `xlsx`, copiando o modelo e preenchendo as linhas. Não recrie a formatação do zero.
2. Valide comparando com o modelo: mesmas abas, mesmos cabeçalhos byte a byte, mesma ordem, nenhuma coluna extra, nenhuma célula de cabeçalho mesclada a mais.
3. Aponte à parte, sem mudar o layout, as variações que violam as regras da Shopee: oferta acima de 48% e proporção entre variações acima de 3,9x.
4. Envie com SendUserFile e resuma em 2 ou 3 linhas: quantos anúncios e variações entraram, margem média e os alertas.

## Prompt para usuários do SaaS

Se o usuário pedir o prompt para colocar no SaaS (para os clientes colarem no Claude ou no ChatGPT/Codex), escreva um texto autossuficiente com os passos 1 a 3. Inclua a lista exata de cabeçalhos do modelo e a regra de não alterar o layout. Faça uma versão para Claude (com as ferramentas do navegador) e outra para o Codex, que pede ao usuário a exportação de produtos da Shopee em vez de navegar.