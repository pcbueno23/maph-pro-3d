---
name: "shopee-para-mercado-livre"
description: "Use quando o usuário quiser copiar anúncios da Shopee (título, descrição, imagens, variações) para a conta do Mercado Livre, adaptando ao que o Mercado Livre exige."
---

# Cópia de anúncios Shopee para o Mercado Livre

Copia anúncios da loja Shopee para a conta do Mercado Livre, com imagens e tudo, adaptando título, ficha técnica e preço às regras do Mercado Livre.

Responda sempre em português do Brasil. Trabalhe no Chrome do usuário (ferramentas do painel Claude in Chrome).

## Passo 1. Escolher e coletar

1. Pergunte quais anúncios copiar (todos, uma lista ou os mais vendidos). Se for "os mais vendidos", leia Dados > Informações Gerenciais > Produtos na Shopee.
2. Antes de copiar, confira no Mercado Livre (Vendas > Anúncios) quais já existem, por SKU e por título, para não duplicar.
3. Para cada anúncio, abra a edição na Shopee e colete: título, descrição completa, categoria, atributos, variações (nome, SKU, preço, estoque), peso, dimensões e as URLs das imagens (principal, galeria e imagens das variações). Guarde em `localStorage` enquanto navega.

Se for usar o UpSeller para a cópia (ele também conecta o Mercado Livre), siga a mesma lógica de conferir duplicatas antes.

## Passo 2. Adaptar para o Mercado Livre

- **Título:** até 60 caracteres, formato produto + marca/modelo + atributo principal. Sem emojis, sem caixa alta inteira, sem palavras como "promoção" ou "frete grátis".
- **Categoria e ficha técnica:** escolha a categoria do Mercado Livre e preencha todos os atributos obrigatórios. A ficha técnica pesa na busca. Não invente atributo: o que não estiver no anúncio da Shopee, pergunte.
- **Descrição:** texto puro (o Mercado Livre não aceita HTML, links, telefone nem menção a outras plataformas). Remova referências à Shopee. Mantenha o tom natural, sem travessões e sem cara de texto de IA.
- **Imagens:** a primeira precisa ter fundo branco e o produto inteiro, sem texto, selo ou marca d'água. Se a capa da Shopee tiver texto ou fundo colorido, avise o usuário e sugira usar outra da galeria como capa (ou gerar uma nova com a skill `fotos-produto-meta-ai`).
- **Variações:** mapeie para os atributos de variação que a categoria aceita (cor, tamanho, quantidade). Mantenha os mesmos SKUs.
- **Preço:** as taxas do Mercado Livre são diferentes (tarifa por tipo de anúncio Clássico/Premium, custo fixo abaixo de certo valor e frete). Calcule o preço que mantém a margem que o usuário quer e mostre a conta. Confirme as tarifas atuais no simulador do Mercado Livre em vez de usar números de memória.

## Passo 3. Publicar

Mostre ao usuário, por anúncio: título novo, categoria, preço, tipo de anúncio e capa escolhida. Publicar altera conteúdo público, então peça confirmação explícita antes. Para enviar imagens, use as URLs da Shopee quando o formulário aceitar link. Se for preciso fazer upload de arquivo, peça ao usuário para anexar as imagens no chat.

## Passo 4. Entregar

Tabela final: produto, SKU, link do anúncio no Mercado Livre, preço, status (ativo, em revisão, com problema) e o que ficou pendente (atributo faltando, capa a trocar).