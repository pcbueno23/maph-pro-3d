---
name: "shopee-roas-real"
description: "Use quando o usuário pedir o ROAS real da Shopee: vendas diárias de Informações Gerenciais divididas pelo gasto diário do Shopee Ads, comparação dia a dia e relatório em PDF."
---

# ROAS real Shopee (vendas totais / gasto em Ads)

O usuário não confia no ROAS mostrado no Shopee Ads, porque a Shopee usa a própria atribuição e às vezes credita aos anúncios mais do que a loja vendeu no dia. O ROAS real é:

**ROAS real do dia = Vendas do dia (Informações Gerenciais, pedido pago) / Investimento em Ads do dia (Shopee Ads)**

Padrão: últimos 14 dias completos (de D-14 até ontem; o dia de hoje fica de fora por estar incompleto). Se o usuário pedir outro período, use o que ele pedir.

Tudo é feito no Chrome do usuário (ferramentas chrome_*), na aba que ele está usando, com a sessão já logada na Central do Vendedor (seller.shopee.com.br). Não pedir senha.

## 1. Calcular os timestamps

Os dias da Shopee começam à meia-noite de Brasília (UTC-3), ou seja, 03:00 UTC.
- start_time = meia-noite BRT do primeiro dia, em epoch segundos
- end_time (Ads) = 23:59:59 BRT do último dia
- Para converter um timestamp de volta em data: `new Date((ts - 3*3600)*1000).toISOString().slice(0,10)`

## 2. Vendas diárias (Informações Gerenciais)

1. Navegar para `https://seller.shopee.com.br/datacenter/overview`.
2. No seletor "Período dos Dados", escolher "Últimos 30 Dias" (isso faz a página gravar o SPC_CDS nas requisições).
3. Pegar a URL da chamada `key-metrics` com chrome_read_network_requests (filtro `mydata`) para reaproveitar o parâmetro `SPC_CDS`.
4. Rodar via chrome_javascript_tool:

```js
const r = await fetch('/api/mydata/v3/dashboard/key-metrics/?SPC_CDS=<SPC_CDS>&SPC_CDS_VER=2&start_time=<inicio_30d>&end_time=<fim_30d>&period=past30days&fetag=fetag',{credentials:'include'}).then(r=>r.json());
const f=k=>r.result[k].points.map(p=>new Date((p.timestamp-3*3600)*1000).toISOString().slice(0,10)+'='+p.value).join(' ');
'GMV '+f('paid_gmv')+' | ORD '+f('paid_orders')
```

- `paid_gmv` = "Vendas" do painel (pedidos pagos). Conferir que o total bate com o card "Vendas" da tela.
- `paid_orders` = pedidos pagos.
- Ficar só com os dias do período pedido.

## 3. Gasto diário (Shopee Ads)

1. Navegar para `https://seller.shopee.com.br/portal/marketing/pas/index`.
2. Instalar um interceptador de XHR para capturar o corpo da chamada `get_time_graph` (ela é POST e leva um `device_sz_fingerprint` que precisa ser reaproveitado):

```js
window.__cap=[]; const oo=XMLHttpRequest.prototype.open, os=XMLHttpRequest.prototype.send;
XMLHttpRequest.prototype.open=function(m,u){this.__u=u;return oo.apply(this,arguments)};
XMLHttpRequest.prototype.send=function(b){ if(/time_graph/.test(this.__u)) window.__cap.push({b}); return os.apply(this,arguments)}; 'ok'
```

3. Em "Desempenho de Anúncios de Produtos", abrir o seletor de período e escolher "Últimos 3 meses" para disparar a chamada. Ler `window.__cap[0].b`.
4. Reenviar o mesmo corpo trocando só `start_time` e `end_time`:

```js
const p=JSON.parse(window.__cap[0].b); p.start_time=<inicio>; p.end_time=<fim>;
const r=await new Promise(res=>{const x=new XMLHttpRequest(); x.open('POST','/api/pas/v1/report/get_time_graph/'); x.setRequestHeader('Content-Type','application/json;charset=UTF-8'); x.onload=()=>res(x.responseText); x.send(JSON.stringify(p));});
const j=JSON.parse(r); j.data.report_by_time.map(d=>new Date((+d.key-3*3600)*1000).toISOString().slice(0,10)+' cost='+d.metrics.cost+' gmv='+d.metrics.broad_gmv+' ord='+d.metrics.broad_order).join('\n')
```

- **Os valores vêm multiplicados por 100.000.** `cost/1e5` = investimento em R$; `broad_gmv/1e5` = vendas atribuídas pelo Ads.
- Conferir: a soma do gasto deve bater com o card "Investimento" do período.
- Se o interceptador não capturar nada, conferir os nomes em `performance.getEntriesByType('resource')` (só o caminho, sem query string) e ajustar.

## 4. Montar o PDF

Carregar a skill `pdf` e gerar com reportlab + matplotlib, no scratchpad, depois enviar com SendUserFile. Conteúdo:

1. Título "ROAS real dia a dia · Shopee", período e data de geração.
2. Quatro cards: Vendas totais, Gasto em Ads, ROAS real (em laranja #EE4D2D), ROAS do Shopee Ads (soma broad_gmv / soma cost).
3. Um parágrafo curto explicando a conta e quanto o ROAS da Shopee fica acima ou abaixo do real.
4. Tabela dia a dia: Dia | dia da semana | Pedidos | Vendas | Gasto Ads | ROAS real (negrito) | ROAS Shopee | Vendas Ads*. Linha de total no fim. Destacar em rosa claro (#FFE9E3) a célula Vendas Ads quando ela for maior que as Vendas totais do dia, com nota de rodapé explicando.
5. Gráfico de linha: ROAS real (laranja, com rótulo em cada ponto) x ROAS do Shopee Ads (cinza tracejado), com linha da média.
6. Gráfico de barras: Vendas x Gasto em Ads por dia.
7. Rodapé com as fontes (Informações Gerenciais > Visão Geral, Produto Pago; Shopee Ads > Todos os Anúncios de Produtos) e o aviso de que o dia de hoje ficou de fora.

Formatação brasileira: R$ 1.234,56 e decimais com vírgula. Nome do arquivo: `ROAS_real_Shopee_<N>dias.pdf`.

## 5. Resposta no chat

Curta, em português: total vendido, total gasto, ROAS real x ROAS da Shopee, quantos dias a Shopee atribuiu mais que o vendido (com um exemplo), os 3 piores e os 3 melhores dias. Avisar se algum filtro de período foi alterado na tela. Sem travessões e sem cabeçalhos rotulados.