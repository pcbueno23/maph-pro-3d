---
name: "shopee-padronizar-skus"
description: "Use quando o usuário quiser criar, revisar ou aplicar SKUs legíveis e padronizados (ex.: FAM2-DB-12-3F) nos anúncios e variações da Shopee, em vez de códigos numéricos."
---

# Padronização de SKUs

Cria SKUs que a equipe entende só de olhar: letras e abreviações descritivas, nunca códigos numéricos soltos. Exemplo de referência do usuário: `FAM2-DB-12-3F`.

Responda sempre em português do Brasil.

## Estrutura do SKU

`PRODUTO-COR-TAMANHO-VARIANTE`, separado por hífen, tudo em maiúsculas, sem acento, sem espaço.

- **PRODUTO:** 3 ou 4 letras que lembram o nome, mais um número quando houver mais de um modelo (FAM = Família, CAS = Casal, BAND = Bandeja, KNAT = Kit Natal).
- **COR/ACABAMENTO:** 2 letras (DB = dourado/bege, PR = preto, BR = branco, RS = rosa). Monte a tabela de cores da loja e reuse sempre a mesma abreviação.
- **TAMANHO:** medida em cm ou P/M/G, como aparece no anúncio.
- **VARIANTE:** o que diferencia a variação (3F = 3 filhos, K2 = kit com 2, UN = unitário).

Omita um bloco quando ele não se aplica, mas mantenha a ordem. Cada SKU precisa ser único na loja.

Se o usuário já tiver um padrão ou um dicionário de abreviações, siga o dele e só complete o que faltar.

## Passo 1. Levantar os SKUs atuais

No Chrome do usuário (ferramentas do painel Claude in Chrome), em Produtos > Meus Produtos da Shopee, leia todos os anúncios e variações: nome, nome da variação e SKU atual (da variação e o SKU principal). Pagine até o fim e guarde os dados em `localStorage` enquanto navega.

## Passo 2. Propor

Monte uma tabela: anúncio, variação, SKU atual, SKU proposto e status (manter, trocar, conflito). Mostre também o dicionário de abreviações usado, para a equipe ter como referência. Marque conflito quando dois itens dariam o mesmo SKU.

Avise antes de trocar: SKUs podem estar ligados a outros sistemas (UpSeller, TikTok Shop, Mercado Livre, planilhas e o SaaS de precificação). Trocar na Shopee sem trocar lá pode quebrar o vínculo. Pergunte onde mais o SKU é usado.

Entregue a tabela também em .xlsx (skill `xlsx`) com uma aba de dicionário, para imprimir ou deixar com a equipe.

## Passo 3. Aplicar (só com aprovação)

Alterar anúncio é mudança no conteúdo publicado: peça confirmação explícita da lista final antes. Prefira a edição em massa da Shopee (exportar, editar a coluna de SKU, importar) quando disponível. Baixar e enviar arquivo exige confirmação. Se for editar anúncio por anúncio, altere só o campo SKU e salve.

Depois, leia de novo os anúncios e confirme que cada SKU ficou como o aprovado. Liste o que falhou.