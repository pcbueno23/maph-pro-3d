---
name: "shopee-devolucoes"
description: "Use quando o usuário pedir análise de devoluções, reembolsos ou cancelamentos da loja Shopee: produtos mais devolvidos, motivos, responsabilidade logística, fretes e estornos cobrados, com relatório em PDF."
---

# Análise de Devoluções da Shopee

Levanta todas as solicitações de devolução/reembolso/cancelamento da loja na Central do Vendedor, separa o que é devolução de verdade, apura quanto a Shopee cobrou do vendedor e entrega um relatório em PDF. Tudo é feito no Chrome do usuário (ferramentas do painel do Claude in Chrome), lendo o DOM da página. A Shopee esconde as chamadas internas de API, então não perca tempo procurando requisições de rede.

Responda sempre em português do Brasil.

## Regras importantes

- Nunca digite senha. A página Minha Renda pede a senha de login: peça ao usuário para liberar e espere ele avisar.
- Navegar entre páginas apaga variáveis `window.*`. Guarde os dados coletados em `localStorage` e apague as chaves no final (`__rr`, `__inc`).
- Antes de concluir, confirme que o total coletado bate com o contador "N Solicitações" da lista.

## Passo 1. Coletar a lista de solicitações

Página: `https://seller.shopee.com.br/portal/sale/returnrefundcancel` (aba Todos, sem filtro de data. Confira em "Expandir filtro").

A lista mostra 40 por página. Injete o parser e salve a página atual:

```js
window.__parse=()=>{const L=document.body.innerText.split('\n').map(s=>s.trim()).filter(Boolean);const out=[];for(let i=0;i<L.length;i++){if(L[i]==='ID do Pedido'){let j=i+1;let blk=[L[i-1]];while(j<L.length&&!(L[j+1]==='ID do Pedido')&&!/^\d+$/.test(L[j])){blk.push(L[j]);j++;}out.push(blk);}}return out;};
window.__save=()=>{let all={};try{all=JSON.parse(localStorage.__rr||'{}')}catch(e){};__parse().forEach(b=>{all[b.join('§')]=b});localStorage.__rr=JSON.stringify(all);return Object.keys(all).length};
localStorage.removeItem('__rr');__save()
```

Pagine com o `find` ("pagination button 2/3 at bottom"), clique pelo ref, espere ~4 s e rode `__save()` de novo (reinjete o parser se a página recarregou). O clique às vezes cai na página errada: confira o número de itens e o total acumulado depois de cada página.

## Passo 2. Estruturar e classificar

Cada bloco tem: comprador, ID do pedido, (ID da solicitação), produto, variação, qtd, Reembolso, Compensação, Outros ajustes, motivo, motivo revisado, solução ("Apenas reembolso" ou "Devolução e Reembolso"), status da solicitação, status de entrega/devolução e, no penúltimo campo, a Responsabilidade Logística (Shopee, Vendedor, Pendente ou -).

```js
const num=s=>s&&s.startsWith('R$')?parseFloat(s.slice(2).replace(/\./g,'').replace(',','.')):0;
const P=Object.values(JSON.parse(localStorage.__rr)).map(b=>{const o={order:b[1]};let i=2;if(b[i]==='ID da Solicitação')i+=2;o.prod=b[i];const j=b.indexOf('Outros ajustes',i);o.refund=num(b[b.indexOf('Reembolso',i)+1]);o.comp=num(b[b.indexOf('Compensação',i)+1]);o.motivo=b[j+2];o.sol=b[j+4];o.status=b[j+5];o.rest=b.slice(j+6);o.resp=b[b.length-2];o.pre=/cancelamento foi aprovado/.test(o.rest[0])&&/Não iniciado|^Cancelado/.test(o.rest[1]||'');return o});
```

Separe em três grupos:
1. Cancelamentos antes do envio (`pre = true`): sem custo para a loja.
2. Solicitações canceladas pelo comprador: venda mantida.
3. Devoluções efetivas: todo o resto, incluindo as que ainda estão em andamento.

Sobre as devoluções efetivas, agrupe por produto (quantidade e valor reembolsado), por motivo e por responsabilidade logística. Junte anúncios diferentes do mesmo produto quando o nome deixar claro. Para a taxa de devolução, pegue o total de pedidos no topo de Meus Pedidos ("N Pedidos").

## Passo 3. Extrato de cada pedido devolvido

Para cada devolução efetiva (dê prioridade às com responsabilidade "Vendedor" e às com status Reembolso pago ou Disputa):

1. Abra `https://seller.shopee.com.br/portal/sale/order`, escolha "ID do Pedido" no seletor de busca, digite o ID e tecle Enter.
2. Pegue o primeiro link `a[href*="/sale/order/"]` e navegue até ele.
3. Clique em "Exibir Detalhes da Renda" e leia o trecho entre "Subtotal dos Produtos" e "Pagamento do comprador". Salve em `localStorage.__inc[id]`.

Use `browser_batch` para fazer 3 ou 4 pedidos por chamada. O que procurar:
- Subtotal de Frete negativo: "Taxa de Envio Reversa" e "Taxa de Frete Paga pela Shopee para Você" cobradas do vendedor. É o custo de frete da devolução.
- "Ajuste após reembolso aprovado" negativo: estorno de dinheiro que já tinha sido repassado.
- "Compensação de devolução/reembolso" positiva: dinheiro de volta em disputa ganha.
- Valor final negativo: o pedido deu prejuízo.

Na prática, pedidos com responsabilidade "Shopee" e "apenas reembolso" sem envio saem zerados. O custo de frete aparece nos casos "Vendedor".

## Passo 4. Conferir na carteira

Página: `https://seller.shopee.com.br/portal/finance/wallet/shopeepay` (pode pedir a senha: peça ao usuário).

Filtros: período "Dentro dos últimos 3 meses" (ou o intervalo da loja), Fluxo "Saída", Tipo de transação só "Ajuste". Aplicar. Leia as linhas "Ajuste da Shopee – Débito referente ao pedido … devolução e reembolso aprovado" e o "Valor total". Depois troque para "Entrada" para ver as compensações. Outros débitos (ex.: comissão de afiliados) não entram na conta de devolução.

## Passo 5. Fechar os números

- Fretes de devolução cobrados (soma dos Subtotais de Frete negativos)
- Pedidos que ficaram negativos por estorno
- Prejuízo direto = fretes + negativos
- Receita perdida com reembolsos (soma dos reembolsos das devoluções efetivas)
- Estornos após repasse e compensações recebidas (estorno líquido = estornos − compensações)
- Casos ainda em andamento (podem gerar ajustes novos)

Deixe claro que o custo de produção das peças que não voltaram ("apenas reembolso") não entra no prejuízo direto.

## Passo 6. Relatório em PDF

Carregue a skill `pdf` e monte o relatório com reportlab (A4, cor de destaque #EE4D2D, rodapé com fonte e número da página). Seções:

1. Cabeçalho: loja, período coberto, data de geração.
2. Faixa de indicadores: total de solicitações, devoluções efetivas, taxa de devolução, prejuízo direto.
3. Composição das solicitações (os três grupos).
4. Produtos mais devolvidos (qtd e valor, com linha de total).
5. Motivos (qtd e %).
6. Responsabilidade logística, com destaque para os motivos dos casos "Vendedor".
7. Quanto a Shopee cobrou: tabela de fretes por pedido e tabela de estornos da carteira.
8. Resumo financeiro.
9. Pontos de atenção: produtos/kits que concentram o custo, vídeo da embalagem para disputas, clareza das variações no anúncio, Programa de Devolução Fácil, casos em andamento.

Renderize as páginas em PNG com `pdftoppm`, confira o layout (evite página quase vazia no fim, ajustando espaçamentos) e envie com SendUserFile. Na resposta, um parágrafo curto com os números principais.

## Limpeza

No final, rode `['__rr','__inc'].forEach(k=>localStorage.removeItem(k))` na aba da Shopee.