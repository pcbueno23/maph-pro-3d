---
name: "shopee-precificacao"
description: "Use ao calcular preço de cadastro, desconto, oferta relâmpago ou faixa de preços de variações/kits pra anúncios na Shopee, garantindo que fiquem dentro das regras da plataforma (evita bloqueio por desconto enganoso)."
---

# Precificação Shopee — regras da plataforma

Essas regras foram confirmadas na prática, testando direto no painel do vendedor (Seller Center), não em documentação oficial (a Shopee não publica os números com clareza). Sempre que for montar uma tabela de preços — cadastro, desconto, oferta relâmpago, kits ou variações — para um anúncio da Shopee, aplique as três regras abaixo.

## As três regras confirmadas

1. **Oferta relâmpago: desconto máximo de 50%.** Acima disso a Shopee recusa a promoção ("Política de Descontos Enganosos"). Trabalhe com uma margem de segurança e não passe de **48%** na prática, pra não ficar coladinho no limite.

2. **Proporção entre variações: no máximo 4x.** O preço de cadastro da variação mais cara dividido pelo preço de cadastro da variação mais barata do mesmo anúncio não pode passar de 4. Acima disso a Shopee bloqueia a publicação com o aviso "O preço da variação mais cara dividido pelo preço da variação mais barata excede o limite: 4 vezes". Trabalhe com buffer: mire numa proporção de **até 3,9**, não em 4,0 exato.

3. **Preço de campanha abaixo do menor preço dos últimos 7 dias.** Pra ativar oferta relâmpago/campanha, o preço promocional de cada variação tem que ficar estritamente abaixo do menor preço que aquela variação específica vendeu nos últimos 7 dias (a Shopee mostra esse valor no ícone (i) ao lado do campo, é individual por SKU, não dá pra calcular sem consultar). Se o usuário não souber esse valor, peça pra ele checar no painel antes de fechar o preço definitivo — e sugira um preço com folga (uns R$0,50 a R$1,00 abaixo do limite), nunca exatamente no limite.

## Como isso se encaixa no fluxo de precificação

Quando o usuário pedir uma faixa de preço (avulso + kits, ou variações de um mesmo produto):

1. Pergunte ou use os custos já conhecidos: custo 3D/unidade, custo de envio/embalagem (geralmente fixo por kit, não escala por unidade, a não ser que o usuário diga o contrário).
2. Use a estrutura de taxas da Shopee (confirme com o usuário se os valores mudaram, a comissão é reajustada de tempos em tempos): comissão ~20%, taxa fixa por venda ~R$4,50, taxa de transação ~2%, tributação ~5% (todos incidem sobre o preço final ao cliente, não sobre o preço de cadastro).
3. Defina o preço final ao cliente (preço com oferta relâmpago ativa + cupom loja, geralmente 5% limitado a R$1) que faça sentido pro produto/fase (ranqueamento = preço baixo; fase de margem = preço mais alto).
4. Calcule o preço de cadastro necessário pra chegar nesse preço final, dada a % de oferta relâmpago escolhida (≤48%):
   - Preço após oferta relâmpago = Cadastro × (1 − oferta%)
   - Cupom = mínimo entre (5% × preço após oferta) e o teto (ex.: R$1)
   - Preço final = preço após oferta − cupom
   - Ou seja: Cadastro = (Preço final + teto do cupom) ÷ (1 − oferta%) — válido quando o cupom bate no teto (o que costuma acontecer acima de ~R$37 de preço após oferta); se o cupom não bater no teto, use Cadastro = Preço final ÷ ((1 − oferta%) × (1 − cupom%)).
5. Margem estimada = Preço final × (1 − comissão% − taxa de transação% − tributação%) − custo do produto − taxa fixa.
6. Antes de fechar a tabela, confira as três regras: nenhuma oferta relâmpago acima de 48%, a proporção entre a variação mais cara e mais barata (pelos preços de CADASTRO) até 3,9x, e avise que o preço final de cada variação precisa ser conferido contra o "menor preço dos últimos 7 dias" dela no painel antes de ativar a campanha.
7. Se as regras 1 e 2 entrarem em conflito (não dá pra manter uma variação barata como "gancho" e outra no preço ideal de margem ao mesmo tempo), explique o trade-off ao usuário com números concretos das duas opções (ex.: reduzir a variação mais cara vs. subir a mais barata) e pergunte qual prioridade ele quer — ranqueamento (preço-gancho baixo) ou margem (preço mais alto nas variações caras).

Sempre entregue a tabela final com: preço de cadastro, % de oferta relâmpago, preço final ao cliente, margem estimada (R$ e %), e a proporção entre a variação mais cara e mais barata — pra ficar claro que está dentro do limite de 4x.