---
name: "shopee-pesquisa-concorrentes"
description: "Use quando o usuário pedir pesquisa de produtos ou concorrentes na Shopee no nicho de decoração e papelaria impressos em 3D: preços, vendas, avaliações e oportunidades."
---

# Pesquisa de produtos e concorrentes na Shopee

Garimpa na Shopee produtos impressos em 3D do nicho de decoração e papelaria, compara concorrentes e aponta oportunidades para a loja do usuário. Prioridades já definidas por ele: letreiros e nomes personalizados, organizadores de mesa e vasos modulares de parede. Use essas como padrão quando ele não disser o tema.

Responda sempre em português do Brasil. Trabalhe no Chrome do usuário (ferramentas do painel Claude in Chrome), em shopee.com.br.

## Passo 1. Definir a busca

Para cada tema, monte de 3 a 5 termos como o comprador digitaria (ex.: "nome personalizado mesa", "letreiro nome 3d", "organizador de mesa escritório", "vaso de parede modular"). Pergunte se ele quer incluir algum.

## Passo 2. Coletar

Para cada termo, busque em shopee.com.br e ordene por "Mais Vendidos". Leia os primeiros 30 a 40 resultados pelo DOM: título, preço (e faixa, quando houver variações), quantidade vendida, avaliação média, localização, se é Shopee Mall/indicado e link. Descarte o que não for produto impresso em 3D ou fora do nicho. Retire duplicatas entre termos.

Abra os 5 a 10 anúncios mais vendidos de cada tema e anote: variações oferecidas (tamanhos, cores, kits), personalização, prazo de envio, número de fotos e se tem vídeo, além dos pontos mais citados nas avaliações negativas (quebra na entrega, tamanho menor que o esperado, cor diferente). As reclamações são onde está a oportunidade.

Não copie fotos nem textos dos concorrentes para o relatório. Descreva com suas palavras e deixe o link.

## Passo 3. Analisar

Por tema:
- faixa de preço (mínimo, mediana, máximo) e a faixa onde se concentram as vendas
- volume total vendido entre os 10 primeiros (indica tamanho da demanda)
- quantos vendedores dividem essa demanda (concentração)
- o que os líderes têm em comum
- lacunas: variações que ninguém oferece, reclamações frequentes, fotos fracas

Compare com a loja do usuário quando ele já vende algo parecido. Para checar se o preço de mercado fecha a conta, use a skill `shopee-precificacao` com os custos de impressão que ele informar. Não estime tempo de impressão nem gasto de filamento sem os dados dele.

## Passo 4. Entregar

Relatório em PDF (skill `pdf`) ou planilha (skill `xlsx`), como o usuário preferir: uma seção por tema com a tabela dos principais concorrentes (com link), a análise e de 2 a 3 ideias concretas de produto ou variação com o preço-alvo sugerido. No fim, um ranking dos temas por oportunidade (demanda alta, concorrência dispersa, margem viável).

Se o usuário for criar o anúncio de uma das ideias, a skill `comandante-criativo-anuncio` segue a partir daqui.