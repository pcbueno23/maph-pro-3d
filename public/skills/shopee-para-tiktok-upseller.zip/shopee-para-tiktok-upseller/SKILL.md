---
name: "shopee-para-tiktok-upseller"
description: "Use quando o usuário quiser levar anúncios da Shopee para o TikTok Shop pelo UpSeller sem duplicar anúncios, ou escolher quais produtos validados na Shopee migrar e anunciar."
---

# Migração Shopee para TikTok Shop via UpSeller

Leva anúncios da Shopee para o TikTok Shop usando o UpSeller (app.upseller.com), **sem criar anúncio duplicado**, e prioriza produtos já validados na Shopee. O usuário está no plano gratuito do UpSeller: mapeamento de produto com armazém e sincronização de estoque não estão disponíveis, então o estoque do TikTok precisa ser conferido à parte.

Responda sempre em português do Brasil. Trabalhe no Chrome do usuário (ferramentas do painel Claude in Chrome).

## Passo 1. Escolher o que migrar

1. Na Shopee, em Dados > Informações Gerenciais > Produtos (últimos 30 dias), leia vendas, pedidos e conversão por produto.
2. Se o usuário tiver rodado a skill `shopee-roas-real` ou `shopee-devolucoes`, use esses resultados para descartar produtos com ROAS ruim ou muita devolução.
3. Monte uma lista ordenada: produtos validados (vendas constantes, boa avaliação, pouca devolução) primeiro. Mostre a lista e deixe o usuário confirmar quais migrar.

## Passo 2. Ver o que já existe no TikTok Shop

Antes de qualquer migração, liste todos os anúncios que já estão no TikTok Shop, tanto no UpSeller (lista de anúncios da loja TikTok) quanto no Seller Center do TikTok Shop. Inclua rascunhos e anúncios em revisão. Compare com a lista da Shopee por:
- SKU (o mais confiável, se o padrão for o mesmo nas duas lojas)
- título normalizado (sem acento, minúsculo, sem palavras de tamanho/cor)
- imagem principal, quando houver dúvida

Marque cada produto como: já existe, não existe ou dúvida. Dúvidas vão para o usuário decidir. Nunca migre um produto marcado como "já existe".

## Passo 3. Migrar pelo UpSeller

No UpSeller, use a função de cópia/migração de anúncios da loja Shopee para a loja TikTok Shop, só com os produtos aprovados. Antes de publicar, revise em cada anúncio:
- categoria e atributos obrigatórios do TikTok
- título dentro do limite do TikTok, sem termos de outra plataforma ("Shopee", "frete grátis Shopee")
- variações e SKUs iguais aos da Shopee
- preço: confirme com o usuário a política de preço para o TikTok (as taxas são diferentes das da Shopee)
- estoque conferido à mão
- peso e dimensões da embalagem

Publicar ou enviar para revisão altera conteúdo público: mostre o resumo do lote (produtos, preços, estoque) e peça confirmação explícita antes de publicar.

## Passo 4. Conferir e entregar

Depois da migração, liste de novo os anúncios do TikTok Shop e confirme que não surgiu duplicata. Entregue uma tabela curta: produto, SKU, status no TikTok (publicado, em revisão, rejeitado e motivo) e se tem vídeo.

Como o usuário usa um vídeo por produto e quer anunciar no TikTok os produtos validados na Shopee, termine indicando quais migrados já têm vídeo pronto para campanha (meta inicial de ROAS 5 a 6 no TikTok Shop Ads).